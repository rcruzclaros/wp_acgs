<?php
/**
 * Search & Filter Pro 
 *
 * Sample Results Template
 * 
 * @package   Search_Filter
 * @author    Ross Morsali
 * @link      http://www.designsandcode.com/
 * @copyright 2014 Designs & Code
 * 
 * Note: these templates are not full page templates, rather 
 * just an encaspulation of the your results loop which should
 * be inserted in to other pages by using a shortcode - think 
 * of it as a template part
 * 
 * This template is an absolute base example showing you what
 * you can do, for more customisation see the WordPress docs 
 * and using template tags - 
 * 
 * http://codex.wordpress.org/Template_Tags
 *
 */

if ( $query->have_posts() )
{
	$res_f = '';$res = '';
	while ($query->have_posts())
	{
		$query->the_post();
			
			// echo '<div class="row-fluid filter-results">';
			// 	echo '<div class="rhcol span2">';
			// 		echo '<img src="'.get_field('vendor_logo', get_the_ID()).'" />';
			// 	echo '</div>';
			// 	echo '<div class="rhcol span7">';
			// 		echo '<div class="item-title">'.get_the_title().'</div>';
			// 		echo '<div class="item-subtitle">'.get_field('sub_title', get_the_ID()).'</div>';
			// 		echo '<div class="item-content">'.get_the_excerpt().'</div>';
			// 		echo '<div class="item-little-content"><span class="little-content">'.substr(get_the_excerpt(), 0, 90).'... <a href="#">Read More</a></span><span class="hide-little-content">'.get_the_excerpt().'</span></div>';
			// 	echo '</div>';
			// 	echo '<div class="rhcol span3">';
			// 		echo '<a href="'.get_the_permalink().'" class="btn">Apply Now</a>';
			// 	echo '</div>';
			// echo '</div>';
			
				
			// else
			if(get_field('featured_company', get_the_ID())!=''){
				$res_f .= '<div class="row-fluid filter-results" style="background-color: yellow">'; 
					$res_f .= '<div class="rhcol span2">';
						$res_f .= '<img src="'.get_field('vendor_logo', get_the_ID()).'" />';
					$res_f .= '</div>';
						$res_f .= '<div class="rhcol span7">';
							$res_f .= '<div class="item-title">'.get_the_title().'</div>';
							$res_f .= '<div class="item-subtitle">'.get_field('sub_title', get_the_ID()).'</div>';
							$res_f .= '<div class="item-content">'.get_the_excerpt().'</div>';
							$res_f .= '<div class="item-little-content"><span class="little-content">'.substr(get_the_excerpt(), 0, 90).'... <a href="#">Read More</a></span><span class="hide-little-content">'.get_the_excerpt().'</span></div>';
						$res_f .= '</div>';
						$res_f .= '<div class="rhcol span3">';
							$res_f .= '<a href="'.get_the_permalink().'" class="btn">Apply Now</a>';
					$res_f .= '</div>';
				$res_f .= '</div>';
			} else {
				$res .= '<div class="row-fluid filter-results">'; 
					$res .= '<div class="rhcol span2">';
						$res .= '<img src="'.get_field('vendor_logo', get_the_ID()).'" />';
					$res .= '</div>';
						$res .= '<div class="rhcol span7">';
							$res .= '<div class="item-title">'.get_the_title().'</div>';
							$res .= '<div class="item-subtitle">'.get_field('sub_title', get_the_ID()).'</div>';
							$res .= '<div class="item-content">'.get_the_excerpt().'</div>';
							$res .= '<div class="item-little-content"><span class="little-content">'.substr(get_the_excerpt(), 0, 90).'... <a href="#">Read More</a></span><span class="hide-little-content">'.get_the_excerpt().'</span></div>';
						$res .= '</div>';
						$res .= '<div class="rhcol span3">';
							$res .= '<a href="'.get_the_permalink().'" class="btn">Apply Now</a>';
					$res .= '</div>';
				$res .= '</div>';
			}
		
		// echo '<hr />';
	}
	echo $res_f;echo $res;
	echo '<div class="pagination"><a href="#" class="myprefix-button color-blue large transparent" style="display:none;"><span>Load More</span></a></div>';
}
else
{
	echo "No Results Found";
}
?>